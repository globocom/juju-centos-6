
from juju.errors import JujuError


class UnitDeploymentError(JujuError):
    """An error occured while deploying a service unit"""
