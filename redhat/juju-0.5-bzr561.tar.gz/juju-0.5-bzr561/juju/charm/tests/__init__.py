def local_charm_id(charm):
    return "local:series/%s-%s" % (
        charm.metadata.name, charm.get_revision())
