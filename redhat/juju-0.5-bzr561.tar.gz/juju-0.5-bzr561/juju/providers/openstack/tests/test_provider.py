"""Testing for the OpenStack provider interface"""
from twisted.internet.defer import inlineCallbacks

from juju.lib.testing import TestCase
from juju.environment.errors import EnvironmentsConfigError
from juju.machine.constraints import ConstraintSet

from juju.providers.openstack.files import FileStorage
from juju.providers.openstack.provider import MachineProvider
from juju.providers.openstack.tests import OpenStackTestMixin


class ProviderTestCase(TestCase):

    environment_name = "testing"

    _test_environ = {
        "NOVA_URL": "http://environ.invalid",
        "NOVA_API_KEY": "env-key",
        "EC2_SECRET_KEY": "env-xxxx",
        "NOVA_PROJECT_ID": "env-project",
        }

    def get_config(self):
        return {
            "type": "openstack",
            "auth-mode": "keypair",
            "access-key": "key",
            "secret-key": "xxxxxxxx",
            "auth-url": "http://testing.invalid",
            "project-name": "project",
            "control-bucket": self.environment_name,
            }

    def test_empty_config_raises(self):
        """Passing no config raises an exception about lacking credentials"""
        self.change_environment()
        # XXX: Should this raise EnvironmentsConfigError instead?
        self.assertRaises(ValueError,
            MachineProvider, self.environment_name, {})

    def test_client_params(self):
        """Config details get passed through to OpenStack client correctly"""
        config = self.get_config()
        provider = MachineProvider(self.environment_name, config)
        creds = provider.credentials
        self.assertEquals("key", creds.access_key)
        self.assertEquals("xxxxxxxx", creds.secret_key)
        self.assertEquals("http://testing.invalid", creds.url)
        self.assertEquals("project", creds.project_name)
        self.assertIs(creds, provider.nova._client.credentials)
        self.assertIs(creds, provider.swift._client.credentials)

    def test_provider_attributes(self):
        """
        The provider environment name and config should be available as
        parameters in the provider.
        """
        provider = MachineProvider(self.environment_name, self.get_config())
        self.assertEqual(provider.environment_name, self.environment_name)
        self.assertEqual(provider.config.get("type"), "openstack")
        self.assertEqual(provider.provider_type, "openstack")

    def test_get_file_storage(self):
        """The file storage is accessible via the machine provider."""
        provider = MachineProvider(self.environment_name, self.get_config())
        storage = provider.get_file_storage()
        self.assertTrue(isinstance(storage, FileStorage))

    def test_config_serialization(self):
        """
        The provider configuration can be serialized to yaml.
        """
        self.change_environment()
        config = self.get_config()
        expected = config.copy()
        config["authorized-keys-path"] = self.makeFile("key contents")
        expected["authorized-keys"] = "key contents"
        provider = MachineProvider(self.environment_name, config)
        self.assertEqual(expected, provider.get_serialization_data())

    def test_config_environment_extraction(self):
        """
        The provider serialization loads keys as needed from the environment.

        Variables from the configuration take precendence over those from
        the environment, when serializing.
        """
        self.change_environment(**self._test_environ)
        provider = MachineProvider(self.environment_name, {
            "auth-mode": "keypair",
            "project-name": "other-project",
            "authorized-keys": "key-data",
            })
        serialized = provider.get_serialization_data()
        expected = {
            "auth-mode": "keypair",
            "access-key": "env-key",
            "secret-key": "env-xxxx",
            "auth-url": "http://environ.invalid",
            "project-name": "other-project",
            "authorized-keys": "key-data",
            }
        self.assertEqual(expected, serialized)

    def test_conflicting_authorized_keys_options(self):
        """
        We can't handle two different authorized keys options, so deny
        constructing an environment that way.
        """
        config = self.get_config()
        config["authorized-keys"] = "File content"
        config["authorized-keys-path"] = "File path"
        error = self.assertRaises(EnvironmentsConfigError,
            MachineProvider, self.environment_name, config)
        self.assertEquals(
            str(error),
            "Environment config cannot define both authorized-keys and "
            "authorized-keys-path. Pick one!")


class GetConstraintSetTests(OpenStackTestMixin, TestCase):

    @inlineCallbacks
    def test_get_constraints(self):
        self.expect_nova_get("flavors",
            response={'flavors': self.default_flavors})
        self.mocker.replay()
        provider = self.get_provider()
        cs = yield provider.get_constraint_set()
        self.assertIsInstance(cs, ConstraintSet)
        cs2 = yield provider.get_constraint_set()
        self.assertIsInstance(cs2, ConstraintSet)
        self.assertEqual(cs, cs2)
