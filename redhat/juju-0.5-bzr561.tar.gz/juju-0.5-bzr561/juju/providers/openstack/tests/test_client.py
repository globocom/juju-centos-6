"""Tests for OpenStack API twisted client"""

from juju.lib import testing

from juju.providers.openstack import client


class StubClient(client._OpenStackClient):

    def __init__(self):
        self.url = "http://testing.invalid"

    make_url = client._OpenStackClient._make_url


class TestMakeUrl(testing.TestCase):

    def setUp(self):
        self.client = StubClient()
        self.client.services = {
            "compute": self.client.url + "/nova",
            "object-store": self.client.url + "/swift",
            }

    def test_list_str(self):
        self.assertEqual("http://testing.invalid/nova/servers",
            self.client.make_url("compute", ["servers"]))
        self.assertEqual("http://testing.invalid/swift/container/object",
            self.client.make_url("object-store", ["container", "object"]))

    def test_list_int(self):
        self.assertEqual("http://testing.invalid/nova/servers/1000",
            self.client.make_url("compute", ["servers", 1000]))
        self.assertEqual("http://testing.invalid/nova/servers/1000/detail",
            self.client.make_url("compute", ["servers", 1000, "detail"]))

    def test_list_unicode(self):
        url = self.client.make_url("object-store", ["container", u"\xa7"])
        self.assertIsInstance(url, str)
        self.assertEqual("http://testing.invalid/swift/container/%C2%A7", url)

    def test_str(self):
        self.assertEqual("http://testing.invalid/nova/servers",
            self.client.make_url("compute", "servers"))
        self.assertEqual("http://testing.invalid/swift/container/object",
            self.client.make_url("object-store", "container/object"))

    def test_trailing_slash(self):
        self.client.services["object-store"] += "/"
        self.assertEqual("http://testing.invalid/nova/container",
            self.client.make_url("compute", "container"))
        self.assertEqual("http://testing.invalid/nova/container/object",
            self.client.make_url("compute", ["container", "object"]))


class TestPlan(testing.TestCase):
    """Ideas for tests needed"""

    # auth request without auth
    # get bytes, content-length 0, return ""
    # get bytes, not ResponseDone, raise wrapped in ProviderError (with any bytes?)
    # get bytes, type json, return bytes
    # get json, content length 0, raise ProviderError
    # get json, bad header (several forms), raise ProviderError (with bytes)
    # get json, not ResponseDone, raise wrapped in ProviderError
    #    (with any bytes?)
    # get json, undecodable, raise wrapped in ProviderError with bytes
    # get json, mismatching root, raise ProviderError with bytes or json?
    # wrong code, no json header, raise ProviderError with bytes
    # wrong code, not ResponseDone, raise ProviderError from code
    #    with any bytes
    # wrong code, undecodable, raise ProviderError from code with bytes
    # wrong code, has mystery root, raise ProviderError from code with bytes or json?
    # wrong code, has good root, no message
    # wrong code, has good root, no code
    # wrong code, has good root, differing code
    # wrong code, has good root, message, and matching code
