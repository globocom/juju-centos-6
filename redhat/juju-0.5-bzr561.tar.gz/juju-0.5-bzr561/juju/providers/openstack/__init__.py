"""Support for using OpenStack as a cloud provider for juju"""

__all__ = ['MachineProvider']

from .provider import MachineProvider
