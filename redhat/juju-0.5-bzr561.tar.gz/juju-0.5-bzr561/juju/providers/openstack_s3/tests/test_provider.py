"""Testing for the OpenStack provider interface"""

from juju.lib.testing import TestCase
from juju.environment.errors import EnvironmentsConfigError

from juju.providers.ec2.files import FileStorage
from juju.providers.openstack_s3 import MachineProvider


class ProviderTestCase(TestCase):

    environment_name = "testing"

    _test_environ = {
        "NOVA_URL": "http://environ.invalid",
        "NOVA_API_KEY": "env-key",
        "EC2_ACCESS_KEY": "env-key:env-project",
        "EC2_SECRET_KEY": "env-xxxx",
        "NOVA_PROJECT_ID": "env-project",
        "S3_URL": "http://environ.invalid:3333",
        }

    def get_config(self):
        return {
            "type": "openstack_s3",
            "auth-mode": "keypair",
            "access-key": "key",
            "secret-key": "xxxxxxxx",
            "auth-url": "http://testing.invalid",
            "project-name": "project",
            "control-bucket": self.environment_name,
            "combined-key": "key:project",
            "s3-uri": "http://testing.invalid:3333",
            }

    def test_client_params(self):
        """Config details get passed through to OpenStack client correctly"""
        config = self.get_config()
        provider = MachineProvider(self.environment_name, config)
        creds = provider.credentials
        self.assertEquals("key", creds.access_key)
        self.assertEquals("xxxxxxxx", creds.secret_key)
        self.assertEquals("http://testing.invalid", creds.url)
        self.assertEquals("project", creds.project_name)
        self.assertIs(creds, provider.nova._client.credentials)

    def test_s3_params(self):
        """Config details get passed through to txaws S3 client correctly"""
        config = self.get_config()
        s3 = MachineProvider(self.environment_name, config).s3
        self.assertEquals("http://testing.invalid:3333/", s3.endpoint.get_uri())
        self.assertEquals("key:project", s3.creds.access_key)
        self.assertEquals("xxxxxxxx", s3.creds.secret_key)

    def test_provider_attributes(self):
        """
        The provider environment name and config should be available as
        parameters in the provider.
        """
        provider = MachineProvider(self.environment_name, self.get_config())
        self.assertEqual(provider.environment_name, self.environment_name)
        self.assertEqual(provider.config.get("type"), "openstack_s3")
        self.assertEqual(provider.provider_type, "openstack_s3")

    def test_get_file_storage(self):
        """The file storage is accessible via the machine provider."""
        provider = MachineProvider(self.environment_name, self.get_config())
        storage = provider.get_file_storage()
        self.assertTrue(isinstance(storage, FileStorage))

    def test_config_serialization(self):
        """
        The provider configuration can be serialized to yaml.
        """
        self.change_environment()
        config = self.get_config()
        expected = config.copy()
        config["authorized-keys-path"] = self.makeFile("key contents")
        expected["authorized-keys"] = "key contents"
        provider = MachineProvider(self.environment_name, config)
        self.assertEqual(expected, provider.get_serialization_data())

    def test_config_environment_extraction(self):
        """
        The provider serialization loads keys as needed from the environment.

        Variables from the configuration take precendence over those from
        the environment, when serializing.
        """
        self.change_environment(**self._test_environ)
        provider = MachineProvider(self.environment_name, {
            "auth-mode": "keypair",
            "project-name": "other-project",
            "authorized-keys": "key-data",
            })
        serialized = provider.get_serialization_data()
        expected = {
            "auth-mode": "keypair",
            "access-key": "env-key",
            "secret-key": "env-xxxx",
            "auth-url": "http://environ.invalid",
            "project-name": "other-project",
            "authorized-keys": "key-data",
            "combined-key": "env-key:env-project",
            "s3-uri": "http://environ.invalid:3333",
            }
        self.assertEqual(expected, serialized)

    def test_conflicting_authorized_keys_options(self):
        """
        We can't handle two different authorized keys options, so deny
        constructing an environment that way.
        """
        config = self.get_config()
        config["authorized-keys"] = "File content"
        config["authorized-keys-path"] = "File path"
        error = self.assertRaises(EnvironmentsConfigError,
            MachineProvider, self.environment_name, config)
        self.assertEquals(
            str(error),
            "Environment config cannot define both authorized-keys and "
            "authorized-keys-path. Pick one!")
